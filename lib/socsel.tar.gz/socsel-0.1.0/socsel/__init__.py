def autorun(f, load=None, save=None, process=1):
    pass

def fetch_repos_from_ranking(lang, n=1000):
    pass
